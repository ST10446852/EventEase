﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EventEase_2.Models;

namespace EventEase_2.Data
{
    public class EventEase_2Context : DbContext
    {
        public EventEase_2Context (DbContextOptions<EventEase_2Context> options)
            : base(options)
        {
        }

        public DbSet<EventEase_2.Models.Venue> Venue { get; set; } = default!;
        public DbSet<EventEase_2.Models.Event> Event { get; set; } = default!;
        public DbSet<EventEase_2.Models.Booking> Booking { get; set; } = default!;
    }
}
