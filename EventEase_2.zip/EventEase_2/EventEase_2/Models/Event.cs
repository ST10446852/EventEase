﻿using System.ComponentModel.DataAnnotations;

namespace EventEase_2.Models
{
    public class Event
    {
        [Key]

        public string EventId { get; set; }
        public string? EventName { get; set; }
        public DateTime? EventDate { get; set; }
        public string? Description { get; set; }

        public List<Booking> Bookings { get; set; }

    }
}
