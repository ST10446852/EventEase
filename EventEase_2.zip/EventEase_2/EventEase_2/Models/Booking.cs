﻿using System.ComponentModel.DataAnnotations;

namespace EventEase_2.Models
{
    public class Booking
    {
        [Key]

        public string BookingId { get; set; }
        public string EventId { get; set; }
        public string VenueId { get;set; }
        public DateTime? BookingDate { get; set; }

        public Event Event { get; set; }
        public Venue Venue { get; set; }
    }
}
