﻿using System.ComponentModel.DataAnnotations;

namespace EventEase_2.Models
{
    public class Venue
    {
        [Key] 
        public string VenueId { get; set; }
        public string? VenueName { get; set; }
        public string? Location { get; set; }
        public int? Capacity { get; set; } 

        public List<Booking> Bookings { get; set; }
    }
}
