﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EventEase_3.Models;

namespace EventEase_3.Data
{
    public class EventEase_3Context : DbContext
    {
        public EventEase_3Context (DbContextOptions<EventEase_3Context> options)
            : base(options)
        {
        }

        public DbSet<EventEase_3.Models.Venue> Venue { get; set; } = default!;
        public DbSet<EventEase_3.Models.Event> Event { get; set; } = default!;
        public DbSet<EventEase_3.Models.Booking> Booking { get; set; } = default!;
    }
}
